package last.project.shopping.domain.orders;

public enum OrderStatus {
    ORDER,CANCEL
}
