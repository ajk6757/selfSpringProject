package last.project.shopping.domain.items;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
