package last.project.shopping.domain.members;

import org.springframework.data.jpa.repository.JpaRepository;

//이메일 회원 중복검사
public interface MemberRepository extends JpaRepository<Member, Long> {
    Member findByEmail(String email);
}
