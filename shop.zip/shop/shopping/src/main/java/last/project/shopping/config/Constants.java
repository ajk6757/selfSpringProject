package last.project.shopping.config;

public class Constants {
    public static final String[] resourceArray = new String[] { "/static/bootstrap/css/**", "/images/**", "/js/**",
            "/modules/**", "/h2-console/**", "/swagger-ui/**" };

    /**
     * 권한제외 대상
     * @see SecurityConfig
     */
    public static final String[] permitAllArray = new String[] { "/css/**","/login.do", "/logout.do", "/swagger-ui/**",
            "/swagger-ui" };


}
