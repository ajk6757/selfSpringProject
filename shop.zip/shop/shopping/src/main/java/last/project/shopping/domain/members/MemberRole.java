package last.project.shopping.domain.members;

public enum MemberRole {
    USER
}
